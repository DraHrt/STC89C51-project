#include "stm32f10x.h"

void Delay(unsigned int i){
		while(i--);
}

//��ֹ����
void SystemInit(void){

}

//��ں���
int main()
{
		//��ʼ��
		RCC_APB2ENR |= (0X1 << 3);
	  RCC_APB2ENR |= (0X1 << 6);
	
		GPIOB_CRL &= ~(0XF << 20);  //[23:20] = 0000
		GPIOB_CRL |= (0X3 << 20);   //[21:20] = 11
		
		GPIOE_CRL &= ~(0XF << 20);  //[23:20] = 0000
		GPIOE_CRL |= (0X3 << 20);   //[21:20] = 11
		
		GPIOB_CRH &= ~(0XF << 0);  //[23:20] = 0000
		GPIOB_CRH |= (0X3 << 0);   //[21:20] = 11
	
		GPIOB_ODR |= (0x1 << 5);
		GPIOE_ODR |= (0x1 << 5);
		//GPIOB_ODR &= ~(0x1 << 8);
		while(1){
				GPIOB_ODR &= ~(0X1 << 5);
				GPIOE_ODR &= ~(0X1 << 5);
				//GPIOB_ODR |= (0X1 << 8);
				Delay(0XFFFFF);
				GPIOB_ODR |= 0X1 << 5;
				GPIOE_ODR |= 0X1 << 5;
				//GPIOB_ODR &= ~(0X1 << 8);
				Delay(0XFFFFF);
		}
}




