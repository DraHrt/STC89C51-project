#include "stm32f10x.h"
#include "led.h"
#include "beep.h"

int main(void){
	LED_Init();
	BEEP_Init();
	while(1){
		//LED_On();
		//BEEP_On();
		Delay(0xfffff);
		LED_Off();
		BEEP_Off();
		Delay(0xfffff);
	}
}
