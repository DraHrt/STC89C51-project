// led.h
#ifndef __LED_H__
#define __LED_H__

#include "stm32f10x.h"

extern void LED_Init (void) ;
extern void LED_On (void) ;
extern void LED_Off (void) ;

extern void Delay(unsigned int i);

#endif
