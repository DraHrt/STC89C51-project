#include "stm32f10x.h"
#include "led.h"
#include "beep.h"
#include "system.h"

int main(void){
	LED_Init();
	BEEP_Init();
	while(1){
		//LED0 = !LED0;
		//LED1 = !LED1;
		//BEEP = !BEEP;
		Delay(0xFFFFF);
	}
}
