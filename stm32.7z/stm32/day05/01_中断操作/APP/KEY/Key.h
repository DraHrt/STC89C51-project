//Key.h
#ifndef __KEY_H__
#define __KEY_H__

#include "stm32f10x.h"
#include "System.h"

// KEY_UP - PA0
#define KEY_UP			PAin(0)
#define KEY_UP_PRESS	1
// KEY0 - PE4
#define KEY0			PEin(4)
#define KEY0_PRESS      2

extern void KEY_Init(void);
extern u8 KEY_Scan(void);

#endif
