//exti.h
#ifndef __EXTI_H__
#define __EXTI_H__

#include "stm32f10x.h"

extern void My_EXTI_Init(void);

#endif
