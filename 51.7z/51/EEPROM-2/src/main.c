#include "Int_LEDMatrix.h"
#include "Dri_Timer0.h"
#include "Int_EEPROM.h"
#include "Com_Util.h"
void main()
{
    // д��EEPROM
    //  unsigned char i = 0;
    //  unsigned char pic[] = {
    //      0xF8, 0x0A, 0xEC, 0xAF, 0xEC, 0x8A, 0xF8, 0x00,             // ��
    //      0x10, 0xF9, 0x97, 0xF1, 0x88, 0xAA, 0xFF, 0xAA, 0x88, 0x00, // ��
    //      0x14, 0x0A, 0xF5, 0x92, 0x92, 0xF5, 0x0A, 0x14, 0x00        // ��
    //  };

    // Int_EEPROM_WriteBytes(0, pic, sizeof(pic));
    // while (1) {}

    // ��ȡEEPROM
    unsigned char i = 0;
    u8 pic[27];
    Int_EEPROM_ReadBytes(0, pic, sizeof(pic));

    Dri_Timer0_Init();
    Int_LEDMatrix_Init();
    while (1) {
        if (i >= sizeof(pic)) {
            i = 0;
        }
        Int_LEDMatrix_Shift(pic[i++]);
        Com_Util_Delay1ms(300);
    }
}
