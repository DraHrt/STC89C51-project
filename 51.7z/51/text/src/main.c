//p273_02.c

#include <stdio.h>

int main()
{
    int a = 10;
    a = a++;
    printf("a = %d\n",a);

    return 0;
}


