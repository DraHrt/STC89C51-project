#include "LED_Matrix.h"
#include <STC89C5xRC.H>
#include "Dri_Timer0.h"
#define SER P34
#define RCLK P35   //�洢�Ĵ���
#define SRCLK P36  //��λ�Ĵ���


static u8 s_buffer[8];


void Int_LEDMatrix_Init()
{
    P0 = 0XFF;
    SRCLK = 0;
    RCLK = 0;

    Dri_Timer0_RegisterCallback(Int_LEDMatrix_RefreshByTimer0);
}

void Int_LEDMatrix_SetPicture(u8 pic[])
{
    u8 i;
    
    for ( i = 0; i < 8; i++)
    {
        s_buffer[i] = pic[i];
    }


    
    
}

void Int_LEDMatrix_Refresh()
{
    u8 i;
    
    for ( i = 0; i < 8; i++)
    {
        P0 = 0XFF;
        //������ʾ��һ��
        if(i == 0)
            SER = 1;
        else
            SER = 0;
        SRCLK = 0;
        SRCLK = 1;

        RCLK = 0;
        RCLK = 1;
        //���õ�ǰ�е���ʾ����
        P0 = ~s_buffer[i];
        Com_Util_Delay1ms(1);
    }
    
}


void Int_LEDMatrix_RefreshByTimer0()
{
    static u8 i;
    P0 = 0XFF;
    //������ʾ��һ��
    if(i == 0)
        SER = 1;
    else
        SER = 0;
    SRCLK = 0;
    SRCLK = 1;

    RCLK = 0;
    RCLK = 1;
    //���õ�ǰ�е���ʾ����
    P0 = ~s_buffer[i];

    i++;
    if(i == 8)
        i = 0;
    
}
