#include <STC89C5xRC.H> 
#include "Int_KeyMatrix.h"


#define column1 P13 
#define column2 P12 
#define column3 P11 
#define column4 P10 



u8 Int_KeyMatrix_CheckSW()
{

    u8 i,j;
    u8 num = 0xF0;
    u8 lines[4]={0x7F,0xBF,0xDF,0xEF};//(lines[i] & 0xF0) | column[j]
    u8 column[4]={0x07,0x0B,0x0D,0x0E,}; //0000 0111    0000 1011    0000 1101    0000 1110     
                                                 
    for(i=0;i<4;i++)                                                                                                    
    {                                                          
        P1 = lines[i];
        for(j=0;j<4;j++)
        {  
            if(P1 == ((lines[i] & num) | column[j]))
            {
                Com_Util_Delay1ms(10);   
                if(P1 == ((lines[i] & num) | column[j]))
                {
                    while(P1 == ((lines[i] & num) | column[j]));
                    return j+1+(i*4);
                }
            }
        }
    }
    return 0; 

}

/*
u8 Int_KeyMatrix_CheckSW()
{
    u8 i,j;
    u8 lines[4]={0x7F,0xBF,0xDF,0xEF};
    u8 column[4][4]={0x77,0x7B,0x7D,0x7E,//0111 0111    0111 1011    0111 1101    0111 1110
                     0xB7,0xBB,0xBD,0xBE,//1011 0111    1011 1011    1011 1101    1011 1110
                     0xD7,0xDB,0xDD,0xDE,//1101 0111    1101 1011    1101 1101    1101 1110
                     0xE7,0xEB,0xED,0xEE //1110 0111    1110 1011    1110 1101    1110 1110
                    };                                         
    for(i=0;i<4;i++)                                                                                                    
    {                                                          
        P1 = lines[i];
        for(j=0;j<4;j++)
        {  
            if(P1 == column[i][j])
            {
                Com_Util_Delay1ms(10);   
                if(P1 == column[i][j])
                {
                    while(P1 == column[i][j]);
                    return j+1+(i*4);
                }
            }
        }
    }
    return 0; 
}
*/

    /*����
    u8 i;
    P1 = 0x7F;  //0111 1111
    for(i=0;i<4;i++)
    {
        if(P1 == (0x77>>i)^0x70)//0111 1111    ��һ�б�����0111 0111    �ڶ��б�����0111 1011    �����б�����0111 1101    �����б�����0111 1110    0111 0000
        {
            Com_Util_Delay1ms(10);   
            if(P1 == (0x77>>i)^0x70)
            {
                while(P1 == (0x77>>i)^0x70);
                return i;
            }
        }
    }
    */



    


        /*2.0�汾
        u8 i;
        for(i=0;i<4;i++)
        {
            P1 = lines[i];
            if(column1 == 0)
            {
                Com_Util_Delay1ms(10);   
                if(column1 == 0)
                {
                    while(column1 == 0);
                    return 1+(i*4);
                }
            }

            if(column2 == 0)
            {
                Com_Util_Delay1ms(10);   
                if(column2 == 0)
                {
                    while(column2 == 0);
                    return 2+(i*4);
                }
            }

            if(column3 == 0)
            {
                Com_Util_Delay1ms(10);   
                if(column3 == 0)
                {
                    while(column3 == 0);
                    return 3+(i*4);
                }
            }

            if(column4 == 0)
            {
                Com_Util_Delay1ms(10);   
                if(column4 == 0)
                {
                    while(column4 == 0);
                    return 4+(i*4);
                }
            }
        }
        */
    
    
   




/*1.0�汾
u8 Int_KeyMatrix_CheckSW()
{
    //����һ��
    P1 = 0x7F;  //0111 1111
    if(column1 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column1 == 0)
        {
            while(column1 == 0);
            return 1;
        }
    }

    if(column2 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column2 == 0)
        {
            while(column2 == 0);
            return 2;
        }
    }

    if(column3 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column3 == 0)
        {
            while(column3 == 0);
            return 3;
        }
    }

    if(column4 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column4 == 0)
        {
            while(column4 == 0);
            return 4;
        }
    }
    
    //���ڶ���
    P1 = 0xBF;  //1011 1111
    if(column1 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column1 == 0)
        {
            while(column1 == 0);
            return 5;
        }
    }

    if(column2 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column2 == 0)
        {
            while(column2 == 0);
            return 6;
        }
    }

    if(column3 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column3 == 0)
        {
            while(column3 == 0);
            return 7;
        }
    }

    if(column4 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column4 == 0)
        {
            while(column4 == 0);
            return 8;
        }
    }
    
    //��������
    P1 = 0xDF;  //1101 1111
    if(column1 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column1 == 0)
        {
            while(column1 == 0);
            return 9;
        }
    }

    if(column2 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column2 == 0)
        {
            while(column2 == 0);
            return 10;
        }
    }

    if(column3 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column3 == 0)
        {
            while(column3 == 0);
            return 11;
        }
    }

    if(column4 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column4 == 0)
        {
            while(column4 == 0);
            return 12;
        }
    }

    //��������
    P1 = 0xEF;  //1110 1111
    if(column1 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column1 == 0)
        {
            while(column1 == 0);
            return 13;
        }
    }

    if(column2 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column2 == 0)
        {
            while(column2 == 0);
            return 14;
        }
    }

    if(column3 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column3 == 0)
        {
            while(column3 == 0);
            return 15;
        }
    }

    if(column4 == 0)
    {
        Com_Util_Delay1ms(10);   
        if(column4 == 0)
        {
            while(column4 == 0);
            return 16;
        }
    }
    return 0;
}

*/

