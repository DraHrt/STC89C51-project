#include "Int_KeyMatrix.h"
#include "Int_DigitalTube.h"
#include "Int_Buzzer.h"
#include "Com_Util.h"
void main()
{
    u8 Key;
    while (1){
        Key = Int_KeyMatrix_CheckSW();
        if(Key!= 0)
        {
            
            Int_DigitalTube_DisplayNum(Key);
            Int_Buzzer_Buzz();     
        }
        Int_DigitalTube_Refresh();
    }
}


