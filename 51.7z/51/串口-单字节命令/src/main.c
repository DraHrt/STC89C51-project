#include "Dri_UART.h"
#include "Com_Util.h"
#include <STC89C5xRC.H>
void main()
{
    char c;
    Dri_UART_Init();
    while (1){
        if (Dri_UART_ReceiveChar(&c))
        {
            if (c == 'A')
            {
                P2 = 0x00;
                Dri_UART_SendStr("Ok: LED is on��");
            }
            else if (c == 'B')
            {
                P2 = 0xFF;
                Dri_UART_SendStr("Ok: LED is off��");
            }
            else
            {
                Dri_UART_SendStr("Error: unknown command��");
            }
            
            
        }
        
    }
}


