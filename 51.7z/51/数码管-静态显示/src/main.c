#include <STC89C5xRC.H> //包含STC89C52的头文件
#include <INTRINS.H>



// 增加自定义类型，简化代码编写
typedef unsigned char u8;
typedef unsigned int u16;
typedef unsigned long u32;


//延时函数
void Delay1ms(u16 count) //@11.0592MHz
{
    u8 i, j;

    while (count > 0)
    {
        count--;
        _nop_();
        i = 2;
        j = 199;
        do
        {
            while (--j)
                ;
        } while (--i);
    }
}



// 数字0-9的编码
static u8 codes[10] = {
    0x3F, // 0
    0x06, // 1
    0x5B, // 2
    0x4F, // 3
    0x66, // 4
    0x6D, // 5
    0x7D, // 6
    0x07, // 7
    0x7F, // 8
    0x6F  // 9
};


u8 buffer[8];


/**
 * @brief 内部方法，让数码管某一位显示特定数字
 * @param position 片选, 从左到右[0-7]
 * @param num 显示想要的数字编码
 */
void DigitalTube_DisplaySingle(u8 position, u8 num)
{
    P0 = 0x00;
    // 首先片选position
    P2 &= 0xE3;//1110 0011
    position <<= 2;
    P2 |= position;

    P0 = num;
}






/**
 * @brief 设置显存数组
 * @param num 待显示的数字
 */
void DigitalTube_DisplayNum(u32 num)
{
    u8 i;
    // 初始化显存数组
    for(i=0;i<8;i++)
    {
        buffer[i]=0x00; 
    }
    // 填充显存数组
    for(i=0;num>0;i++)
    {
        buffer[i]=codes[num%10];
        num /= 10;
    }
}


/**
 * @brief 动态扫描
 */
void DigitalTube_Refresh()
{
    u8 i;
    for(i=0;i<8;i++)
    {
        DigitalTube_DisplaySingle( i, buffer[i]);
        Delay1ms(1);
    }

}




void main()
{
    // 打开数码管总开关
    //DigitalTube_DisplaySingle(0, codes[6]);//第几位 ， 显示几
    DigitalTube_DisplayNum(12345678);//向buffer显存数组中填充数字
    while (1){
        DigitalTube_Refresh();
    }
}
