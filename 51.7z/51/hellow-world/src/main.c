#include <STC89C5xRC.H>
#include <INTRINS.H>
void Delay500ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	i = 4;
	j = 129;
	k = 119;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void Delay100ms()		//@11.0592MHz
{
	unsigned char i, j;

	i = 180;
	j = 73;
	do
	{
		while (--j);
	} while (--i);
}

void main()
{
	unsigned char tmp = 0x01;//0000 0001
	for(;;)
	{
		P2 = ~tmp;
		Delay500ms();
		tmp<<=1;
		if(tmp== 0x00)
			tmp = 0x01;

	}
	

}