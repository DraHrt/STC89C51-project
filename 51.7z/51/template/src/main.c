void main()
{
    while (1){
    }
}


