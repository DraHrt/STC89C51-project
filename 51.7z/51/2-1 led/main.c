#include <REGX52.H>

void main()
{
	P2=0xFE;
}