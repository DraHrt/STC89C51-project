#include <Int_DigitalTube.h>

void main()
{
    Int_DigitalTube_DisplayNum(12345);//��ʾ����
    while (1){
        Int_DigitalTube_Refresh();
    }
}