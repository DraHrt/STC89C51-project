#ifndef __INT_DIGITALTUBE_H__
#define __INT_DIGITALTUBE_H__

#include "Com_Util.h"

void Int_DigitalTube_DisplayNum(u32 num);
void Int_DigitalTube_Refresh();