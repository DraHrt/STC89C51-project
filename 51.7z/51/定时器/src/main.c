#include "Dri_Timer0.h"
void main()
{
    Dri_Timer0_Init();
    while (1){
        
    }
        
}