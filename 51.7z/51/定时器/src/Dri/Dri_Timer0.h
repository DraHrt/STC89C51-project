#ifndef __DRI_TIMER0_H__
#define __DRI_TIMER0_H__

void Dri_Timer0_Init();

#endif /* __DRI_TIMER0_H__ */